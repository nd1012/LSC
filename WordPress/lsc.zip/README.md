# JavaScript `localStorage` Cache WordPress Plugin

**CAUTION**: __BETA__ version!

1. Use the `lsc.zip` to upload and install the plugin in your WordPress site
2. Activate the plugin
3. Configure the plugin at `Settings` -> `LSC`

You can choose the position within the WordPress generated HTML code, at which LSC should be loaded and initialized. You may disable automatic LSC loading optional, if you plan to integrate the required HTML code by yourself (if you use a DIY theme, f.e.).
